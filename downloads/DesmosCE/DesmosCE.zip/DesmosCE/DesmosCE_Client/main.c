/*
 *--------------------------------------
 * Program Name:
 * Author:
 * License:
 * Description:
 *--------------------------------------
*/

#include <srldrvce.h>

#include <keypadc.h>
#include <stdbool.h>
#include <string.h>
#include <tice.h>
#include <ti/screen.h>
#include <ti/getcsc.h>
#include <stdlib.h>
#include <graphx.h>
#include <keypadc.h>
#include <debug.h>

srl_device_t srl;

bool has_srl_device = false;

uint8_t srl_buf[512];

int cursorX = 160;
int cursorY = 120;

unsigned char screenBuffer[9][9];

static usb_error_t handle_usb_event(usb_event_t event, void *event_data,
                                    usb_callback_data_t *callback_data __attribute__((unused))) {
    usb_error_t err;
    /* Delegate to srl USB callback */
    if ((err = srl_UsbEventCallback(event, event_data, callback_data)) != USB_SUCCESS)
        return err;
    /* Enable newly connected devices */
    if(event == USB_DEVICE_CONNECTED_EVENT && !(usb_GetRole() & USB_ROLE_DEVICE)) {
        usb_device_t device = event_data;
        printf("device connected\n");
        usb_ResetDevice(device);
    }

    /* Call srl_Open on newly enabled device, if there is not currently a serial device in use */
    if(event == USB_HOST_CONFIGURE_EVENT || (event == USB_DEVICE_ENABLED_EVENT && !(usb_GetRole() & USB_ROLE_DEVICE))) {

        /* If we already have a serial device, ignore the new one */
        if(has_srl_device) return USB_SUCCESS;

        usb_device_t device;
        if(event == USB_HOST_CONFIGURE_EVENT) {
            /* Use the device representing the USB host. */
            device = usb_FindDevice(NULL, NULL, USB_SKIP_HUBS);
            if(device == NULL) return USB_SUCCESS;
        } else {
            /* Use the newly enabled device */
            device = event_data;
        }

        /* Initialize the serial library with the newly attached device */
        srl_error_t error = srl_Open(&srl, device, srl_buf, sizeof srl_buf, SRL_INTERFACE_ANY, 9600);
        if(error) {
            /* Print the error code to the homescreen */
            printf("Error %d initting serial\n", error);
            return USB_SUCCESS;
        }

        has_srl_device = true;
    }

    if(event == USB_DEVICE_DISCONNECTED_EVENT) {
        usb_device_t device = event_data;
        if(device == srl.dev) {
            srl_Close(&srl);
            has_srl_device = false;
        }
    }

    return USB_SUCCESS;
}
int charToInt(char temp){
    if(temp == '0'){
        return 0;
    }else if(temp == '1'){
        return 1;
    }else if(temp == '2'){
        return 2;
    }else if(temp == '3'){
        return 3;
    }else if(temp == '4'){
        return 4;
    }else if(temp == '5'){
        return 5;
    }else if(temp == '6'){
        return 6;
    }else if(temp == '7'){
        return 7;
    }else if(temp == '8'){
        return 8;
    }else if(temp == '9'){
        return 9;
    }else{
        return 0;
    }
}

void clearCursor(int cx, int cy){
    for(int i = -4; i <= 4; i++){
        gfx_SetColor(screenBuffer[4][i+4]);
        gfx_SetPixel(cx, cy + i);
        gfx_SetColor(screenBuffer[i+4][4]);
        gfx_SetPixel(cx + i, cy);
    }
}

void printCursor(int px, int py, int cx, int cy){
    unsigned char tempScreenBuffer[9][9];
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            int tx = i+(cx-px);
            int ty = j+(cy-py);
            if(tx > -1 && ty > -1 && tx < 9 && ty < 9){
                tempScreenBuffer[i][j] = screenBuffer[tx][ty];
            }else{
                tempScreenBuffer[i][j] = gfx_GetPixel(cx + (i-4), cy + (j-4));
            }
        }
    }

    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            screenBuffer[i][j] = tempScreenBuffer[i][j];
        }
    }

    gfx_SetColor(gfx_RGBTo1555(0, 0, 0));
    for(int i = -4; i <= 4; i++){
        gfx_SetPixel(cx, cy + i);
        gfx_SetPixel(cx + i, cy);
    }
}

void handleKeyInput(){
    kb_Scan();
    bool keys[20] = {
        kb_Data[3] & kb_0,
        kb_Data[3] & kb_1,
        kb_Data[4] & kb_2,
        kb_Data[5] & kb_3,
        kb_Data[3] & kb_4,
        kb_Data[4] & kb_5,
        kb_Data[5] & kb_6,
        kb_Data[3] & kb_7,
        kb_Data[4] & kb_8,
        kb_Data[5] & kb_9,
        kb_Data[6] & kb_Add,
        kb_Data[6] & kb_Sub,
        kb_Data[6] & kb_Mul,
        kb_Data[6] & kb_Div,
        kb_Data[6] & kb_Enter,
        kb_Data[7] & kb_Up,
        kb_Data[7] & kb_Down,
        kb_Data[7] & kb_Left,
        kb_Data[7] & kb_Right,
        kb_Data[1] & kb_Del
    };

    if(kb_Data[7] & kb_Up && cursorY > 0){
        clearCursor(cursorX, cursorY);
        cursorY--;
        printCursor(cursorX, cursorY+1, cursorX, cursorY);
    }

    if(kb_Data[7] & kb_Down && cursorY < 240){
        clearCursor(cursorX, cursorY);
        cursorY++;
        printCursor(cursorX, cursorY-1, cursorX, cursorY);
    }

    if(kb_Data[7] & kb_Left && cursorX > 0){
        clearCursor(cursorX, cursorY);
        cursorX--;
        printCursor(cursorX+1, cursorY, cursorX, cursorY);
    }
        
    if(kb_Data[7] & kb_Right && cursorX < 360){
        clearCursor(cursorX, cursorY);
        cursorX++;
        printCursor(cursorX-1, cursorY, cursorX, cursorY);
    }

    printCursor(cursorX, cursorY, cursorX, cursorY);

    int keysDown = 0;
    for(int i = 0; i < 20; i++){
        if(keys[i]){
            keysDown++;
        }
    }
    if(keysDown > 0){
        char buf[keysDown + 6];
        keysDown = 0;
        for(int i = 0; i < 20; i++){
            if(keys[i]){
                buf[keysDown + 6] = i + '0';
                keysDown++;
            }
        }
        buf[0] = (cursorX / 100) + '0'; buf[1] = ((cursorX % 100) / 10) + '0'; buf[2] = (cursorX % 10) + '0';
        buf[3] = (cursorY / 100) + '0'; buf[4] = ((cursorY % 100) / 10) + '0'; buf[5] = (cursorY % 10) + '0';
        size_t bytes_size = keysDown + 6;
        srl_Write(&srl, buf, bytes_size);
    }
}

int main(void) {
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            screenBuffer[i][j] = 255;
        }
    }

    os_ClrHome();
    gfx_Begin();
    const usb_standard_descriptors_t *desc = srl_GetCDCStandardDescriptors();
    /* Initialize the USB driver with our event handler and the serial device descriptors */
    usb_error_t usb_error = usb_Init(handle_usb_event, NULL, desc, USB_DEFAULT_INIT_FLAGS);
    if(usb_error) {
       usb_Cleanup();
       printf("usb init error %u\n", usb_error);
       do kb_Scan(); while(!kb_IsDown(kb_KeyClear));
       return 1;
    }
    int x = 0;
    int y = 0;
    do {
        kb_Scan();
        
        usb_HandleEvents();

        if(has_srl_device) {
            char in_buf[64];

            handleKeyInput();

            /* Clear the buffer */
            for(int i = 0; i < 64; i++){
                in_buf[i] = '\0';
            }

            /* Read up to 64 bytes from the serial buffer */
            size_t bytes_read = srl_Read(&srl, in_buf, sizeof in_buf);

            /* Check for an error (e.g. device disconneced) */
            if(bytes_read < 0) {
                printf("error %d on srl_Read\n", bytes_read);
                has_srl_device = false;
            } else if(bytes_read > 0) {
                int loops = (charToInt(in_buf[0])*10) + charToInt(in_buf[1]);
                if(loops > 0){
                    /* draw pixels */
                    int r = (charToInt(in_buf[2]) * 100) + (charToInt(in_buf[3]) * 10) + charToInt(in_buf[4]);
                    int g = (charToInt(in_buf[5]) * 100) + (charToInt(in_buf[6]) * 10) + charToInt(in_buf[7]);
                    int b = (charToInt(in_buf[8]) * 100) + (charToInt(in_buf[9]) * 10) + charToInt(in_buf[10]);
                    gfx_SetColor(gfx_RGBTo1555(r, g, b));
                    if(abs(x - cursorX) < 5 && abs(y - cursorY) < 5){
                        screenBuffer[(x - cursorX) + 4][(y - cursorY) + 4] = gfx_RGBTo1555(r, g, b);
                    }
                    for(int i = 0; i < loops; i++){
                        gfx_SetPixel(x, y);
                        x++;
                        if(x == 320){
                            x = 0;
                            y++;
                        }
                        if(y == 240){
                            y = 0;
                        }
                    }
                    
                }else{
                    /* Draw nothing */
                    int noDrawLoops = (charToInt(in_buf[2]) * 100) + (charToInt(in_buf[3]) * 10) + charToInt(in_buf[4]);
                    for(int i = 0; i < noDrawLoops; i++){
                        x++;
                        if(x == 320){
                            x = 0;
                            y++;
                        }
                        if(y == 240){
                            y = 0;
                        }
                    }
                }
                

                /* Write the data back to serial */
                //srl_Write(&srl, in_buf, bytes_read);
            }
        }

    } while(!kb_IsDown(kb_KeyClear));

    usb_Cleanup();
    gfx_End();
    return 0;
}

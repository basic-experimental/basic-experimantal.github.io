#https://basic-experimental.github.io/desmosCE.html

import serial
import serial.tools.list_ports
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import urllib.request
from PIL import Image
from pynput import keyboard, mouse
import os

def handleInput():
    global prevKey, charInputs, charOutputs, cursorX, cursorY, Mx, My
    keys = ser.readline().decode("utf-8")
    if(not len(keys) < 6):
        cursorX = str(keys[0]) + str(keys[1]) + str(keys[2])
        cursorY = str(keys[3]) + str(keys[4]) + str(keys[5])
        if(len(keys) > 6 and keys[6] != prevKey):
            if(keys[6] == ">"):
                Mx = mouseC.position[0]
                My = mouseC.position[1]
                mouseC.position = ((float(cursorX) * 1.5) + 17, (float(cursorY) * 1.5) + 182)
                mouseC.click(mouse.Button.left)
                mouseC.position = (Mx, My)
            elif(charOutputs[charInputs.index(keys[6])] != ""):
                keyboardC.press(charOutputs[charInputs.index(keys[6])])
                prevKey = keys[6]
        else:
            prevKey = ""


opts = Options()
# chromedriver = "Users/Teddy/Desktop/chromedriver_win32/chromedriver"

user_agent =  ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) '
'AppleWebKit/537.36 (KHTML, like Gecko) '
'Chrome/39.0.2171.95 Safari/537.36')
opts.add_argument(f'user-agent={user_agent}')
driver = webdriver.Chrome(opts)

driver.get(os.path.abspath("HTML/script.html"))
prevPix = []
for i in range(76800):
    temp = []
    for j in range(4):
        temp.append(-1)
    prevPix.append(temp)

driver.set_window_size(720, 800)
driver.set_window_position(0, 0)

charInputs = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ":", ";", "<", "=", ">", "?", "@", "A", "B", "C"]
charOutputs = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "-", "*", "/", "=", "", "", "", "", "\b"]
keyboardC = keyboard.Controller()
mouseC = mouse.Controller()
prevKey = ""
keys = 0
loop = 0
cursorX = 160
cursorY = 120
Mx = -1
My = -1

print([comport.device for comport in serial.tools.list_ports.comports()])
port = input("What port number is the device on? ")
ser = serial.Serial('COM' + port, 9600, timeout=0.001)
print("Starting Transmission...")



while(True):
    data = driver.find_element(By.ID, "image").get_attribute("src")
    response = urllib.request.urlopen(data)
    im = Image.open(response.file)
    pix = list(im.getdata())

    x = 0
    while (x < len(pix)):
        same = 0
        while(x < len(pix)-1 and same < 999):
            if(not (pix[x][0] == prevPix[x][0] and pix[x][1] == prevPix[x][1] and pix[x][2] == prevPix[x][2])):
                break
            same += 1
            x += 1

        if(same > 0):
            string = str(same)
            while(len(string) < 5):
                string = "0" + string
            ser.write(bytes(string, 'utf-8') + b"/n")

        inRow = 1
        r = str(pix[x][0])
        g = str(pix[x][1])
        b = str(pix[x][2])
        prevR = r
        prevG = g
        prevB = b
        while(x < len(pix)-1 and inRow < 99):
            r = str(pix[x][0])
            g = str(pix[x][1])
            b = str(pix[x][2])
            if(not abs(int(r)-int(prevR)) + abs(int(g)-int(prevG)) + abs(int(b)-int(prevB)) == 0):
                break
            inRow += 1
            x += 1

        r = prevR
        g = prevG
        b = prevB
        string = str(inRow)
        if(len(string) < 2):
            string = "0" + string

        for i in range(3):
            if(i >= 3-len(r)):
                string += r[i-(3-len(r))]
            else:
                string += "0"
        for i in range(3):
            if(i >= 3-len(g)):
                string += g[i-(3-len(g))]
            else:
                string += "0"
        for i in range(3):
            if(i >= 3-len(b)):
                string += b[i-(3-len(b))]
            else:
                string += "0"
        ser.write(bytes(string, 'utf-8') + b"/n")
        x += 1
        if(loop%30 == 0):
            handleInput()
        loop += 1
    for i in range(len(pix)):
        for j in range(len(pix[0])):
            prevPix[i][j] = pix[i][j]

#ser.close()
